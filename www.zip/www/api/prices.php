<?php
// prices in cents (EUR)
return [
  'lp-003' => 12499,
  'lp-IT003' => 12499,
];